package com.microserves.pilote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PiloteApplication {

	public static void main(String[] args) {
		SpringApplication.run(PiloteApplication.class, args);
	}

}
